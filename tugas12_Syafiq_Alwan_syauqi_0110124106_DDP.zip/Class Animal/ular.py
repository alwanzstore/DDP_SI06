from Animal import *

class ular(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, warna_ikan, jenis_ikan):
        super().__init__( nama, makanan, hidup, berkembang_biak)
        self.warna = warna_ikan
        self.jenis = jenis_ikan
        
    def cetak_ular(self):
        super().cetak()
        print(f'warna ular ini adalah warna {self.warna} dan hewan ini adalah {self.jenis}')

print('---cetak ular----')
print('--objek pertama----')
kobra = ular('ular','daging', 'darat', 'bertelur', 'belang-belang', 'berbahaya')
kobra.cetak_ular()

print('---cetak ular----')
print('--objek kedua----')
kobra = ular('ular','daging', 'darat', 'bertelur', 'belang-belang dll', 'berbahaya')
kobra.cetak_ular()


